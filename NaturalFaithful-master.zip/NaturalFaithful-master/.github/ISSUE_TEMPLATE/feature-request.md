---
name: Feature Request
about: Suggest an idea for this project
title: "[Feature Request] Your Title"
labels: enhancement
assignees: ''

---

**Describe the solution you'd like**

_A clear and concise description of what you want._

<details>
  <summary><b>Additional context</b></summary>

  _Add any other context or screenshots about the feature request here._
</details>
