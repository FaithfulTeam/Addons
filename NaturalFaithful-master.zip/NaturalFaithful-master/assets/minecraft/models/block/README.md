# How it works :
|**!<>!**       |**Finished**                    |**Name**          |**Version**                               |**Displayed**|**Date**  |**Creator(s)**|
|:--------------|:-------------------------------|:-----------------|:-----------------------------------------|:------------|:--------:|:-------------|
|Warn with **@**|yes<br/>no<br/>could change : cc|Name of your model|vX.Y<br/>X : big change<br/>Y small change|On site?     | DD/MM/YY |Creators :)   |

> Last update : 6th January 2020

-------------------------------------------------

## A
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |acacia_door_bottom		  |           |yes          |		   |Juknum|
|        |yes         |acacia_door_bottom_hinge	  |			  |not needed	|		   |Juknum|
|        |yes         |acacia_door_top			  |           |yes          |		   |Juknum|
|        |yes         |acacia_door_top_hinge	  |			  |not needed   |		   |Juknum|
|        |yes         |acacia_trapdoor		      |v1.1       |yes          |	       |Progical *&* Juknum|
|        |yes         |activator_rail			  |           |yes          |		   |Progical|
|        |yes         |activator_rail_on		  | 		  |not needed   |		   |Progical|
|        |yes         |activator_rail_raised	  | 		  |not needed   |		   |Progical|
|        |yes         |activator_rail_on_raised	  |			  |not needed	|		   |Progical|
	
## B
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |bee_nest					  |v2	      |yes          | 27/08/19 |Juknum|
|        |yes         |bee_nest_honey			  |v2	      |yes          | 27/08/19 |Juknum|
|        |yes         |beehive                    |v2	      |yes          | 23/08/19 |Juknum|
|        |yes         |beehive_honey			  |v2	      |yes          | 23/08/19 |Juknum|
|        |yes         |birch_trapdoor			  |v1.1       |yes          |		   |Progical *&* Juknum|
|        |yes         |birch_door_bottom		  |	          |yes          |		   |Progical|
|        |yes         |birch_door_bottom_hinge	  |           |not needed	|          |Progical|
|        |yes         |birch_door_top			  |           |yes          |		   |Progical|
|        |yes         |birch_door_top_hinge		  |   		  |not needed   |		   |Progical|
|        |yes         |blast_furnace			  |           |yes          |		   |Progical|
|        |yes         |blast_furnace_on			  |           |yes          | 		   |Progical|
|        |yes         |bottle_1					  |           |yes          | 25/12/19 |Nekzuris **community**|
|        |yes         |bottle_1_empty			  |	          |not needed	| 25/12/19 |Nekzuris **community**|
|        |yes         |bottle_2					  |           |yes          | 25/12/19 |Nekzuris **community**|
|        |yes         |bottle_2_empty		      |           |yes          | 25/12/19 |Nekzuris **community**|
|        |yes         |bookshelf    		      |           |no           | 04/02/19 |bentogamin **community** & Juknum|
|        |yes         |bookshelf_90    		      |           |no           | 04/02/19 |bentogamin **community** & Juknum|
|        |yes         |brewing_stand			  |           |yes          | 25/12/19 |Nekzuris **community**|
|        |yes         |brown_mushroom			  |v2      	  |yes          |	       |Juknum|

## C
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |cactus              		  |v1         |no           | 01/02/20 |Juknum|
|        |yes         |cartography_table		  |           |yes          |		   |Progical|
|        |yes         |carved_pumpkin			  |v2         |yes          |		   |Progical *&* Juknum|
|        |yes         |composter				  |v1.1       |yes          |		   |Juknum|

## D
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |dark_oak_trapdoor		  |v1.1       |yes          |		   |Progical *&* Juknum|
|        |yes         |dispenser                  |v1.1       |yes          |		   |Juknum *&* Progical|
|        |yes         |dispenser_vertical		  |v1.1       |yes          |          |Juknum *&* Progical|
|        |yes         |detector_rail			  |           |yes          |		   |Progical|
|        |yes         |detector_rail_on			  |   		  |not needed	|		   |Progical|
|        |yes         |detector_rail_raised		  |    	      |not needed	|		   |Progical|
|        |yes         |detector_rail_on_raised	  |           |not needed	|		   |Progical|
|        |yes         |dropper                    |v1.1       |yes          |		   |Juknum *&* Progical|
|        |yes         |dropper_vertical			  |v1.1       |yes          |		   |Juknum *&* Progical|

## E
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|   	 |yes		  |end_portal_frame           |v1         |no           | 01/02/20 |Juknum        |
|   	 |yes		  |end_portal_frame_filled    |v1         |no           | 01/02/20 |Juknum        |

## F
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|    	 |yes		  |furnace                    |v2         |yes          |	       |Progical *&* Juknum|
|    	 |yes		  |furnace_on				  |v2         |yes          |		   |Progical *&* Juknum|

## H
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |hanging_lantern			  |           |yes          |		   |Progical|

## I
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |iron_door_bottom			  |           |yes          |		   |Progical|
|        |yes         |iron_door_bottom_hinge	  |           |not needed	|		   |Progical|
|        |yes         |iron_door_top			  |           |yes          |          |Progical|
|        |yes         |iron_doortop_hinge		  |        	  |not needed   |	       |Progical|
|        |yes         |iron_trapdoor			  |v1.1       |yes          |		   |Progical *&* Juknum|
|        |yes         |iron_bars				  |           |yes          |		   |Progical|

## J
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |jack_o_lantern			  |v2	      |yes          |		   |Progical *&* Juknum|
|        |yes         |jukebox                    |v2	      |yes          | 26/08/19 | Juknum|
|        |yes         |jukebox_record			  |           |yes          | 27/08/19 |Howler *&* Juknum|
|        |yes         |jungle_trapdoor			  |v1.1       |yes          |		   |Progical *&* Juknum|

## L
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |ladder                     |           |yes          |		   |Juknum|
|        |yes         |lectern                    |v2	      |yes          |          |Progical|
|**@**   |cc		  |loom                       |           |yes          | 30/08/19 |Juknum|

## O
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |oak_trapdoor				  |v1.1       |yes          |		   |Progical *&* Juknum|
|        |yes         |oak_door_bottom			  |           |yes          |		   |Progical|
|        |yes         |oak_door_bottom_hinge	  |           |not needed	|		   |Progical|
|        |yes         |oak_door_top				  |           |yes          |		   |Progical|
|        |yes         |oak_door_top_hinge		  |   		  |not needed	|		   |Progical|

## P
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |piston                     |           |yes          | 26/08/19 |Juknum|
|        |yes         |piston_extended			  |    		  |not needed	| 26/08/19 |Juknum|
|        |yes         |powered_rail				  |v2         |yes          |		   |Juknum *&* Progical|
|        |yes         |powered_rail_on			  |v2	      |not needed	|		   |Juknum *&* Progical|
|        |yes         |powered_rail_raised		  |v2         |not needed	|		   |Juknum *&* Progical|
|        |yes         |powered_rail_on_raised	  |v2	      |not needed	|		   |Juknum *&* Progical|
|        |yes         |pumpkin                    |v1	      |yes          | 		   |Juknum|

## R
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |rail                       |v2	      |yes          |	       |Juknum *&* Progical|
|        |yes         |rail_corner		          |v2	      |not needed   |	       |Juknam *&* Progical|
|        |yes         |rail_raised	              |v2	      |not needed   |	       |Juknum *&* Progical|
|        |yes         |red_mushroom	              |v2	      |yes          | 20/08/19 |Juknum|
|        |yes         |redstone_lamp	          |           |yes          | 25/12/19 |Bubminer **community**|
|        |yes         |redstone_lamp_on	          |           |yes          | 25/12/19 |Bubminer **community**|
|        |yes         |redstone_torch	          |v2         |yes          | 22/08/19 |Juknum *&* Progical|
|        |yes         |redstone_wall_torch        |v2	      |not needed   | 22/08/19 |Juknum *&* Progical|

## S
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|**@**   |yes         |smithing_table			  |           |no			| 05/01/20 |Saarlodrie **community** *&* Juknum|
|        |yes         |smoker                     |           |yes          | 04/11/19 |Juknum *&* Saarlodrie **community**|
|        |yes         |smoker_on				  |           |yes          | 04/11/19 |Juknum *&* Saarlodrie **community**|
|        |yes         |spwaner  				  |           |no           | 06/02/19 |Juknum|
|**@**   |yes         |sugar_cane				  |		      |no			| 11/12/19 |Juknum|
|        |yes         |sticky_piston		   	  |           |yes          | 26/08/19 |Juknum|
|        |yes         |stonecutter				  |           |yes          |		   |Juknum|

## T
|**!<>!**|**Finished**|**Name**                   |**Version**|**Displayed**|**Date**  |**Creator(s)**|
|:------:|:----------:|:--------------------------|:---------:|:-----------:|:--------:|:-------------|
|        |yes         |template_piston_head		  |	          |not needed	| 26/08/19 |Juknum        |

