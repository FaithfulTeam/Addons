![Pack Icon](https://raw.githubusercontent.com/Domi04151309/Winter/master/pack.png)

# Winter
Winter is a resource pack for Minecraft Java Edition that works as an add-on for other resourcepacks.
This add-on recolors the game so that it looks like it is winter. OptiFine is required.

### Screenshots
![Minecraft Screenshot](https://raw.githubusercontent.com/Domi04151309/Winter/master/preview.jpg)

### How to Install
You have to download this resource pack and [Faithful x32](https://faithful.team/downloads/) or any other pack.
After you have placed both packs in your resourcepacks folder, select both of them.
It is important that the addon is on top of the default faithful pack!
